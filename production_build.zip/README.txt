Production Build for /Performance
1. Upload all files to your hosting.
2. Run 'node server.js'.
3. Ensure .env variables are set.
